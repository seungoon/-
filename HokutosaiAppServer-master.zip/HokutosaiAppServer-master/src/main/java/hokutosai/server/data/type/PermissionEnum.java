package hokutosai.server.data.type;

public enum PermissionEnum {
	deny,
	allow
}
