package hokutosai.server.data.repository.assessments;

import hokutosai.server.data.entity.assessments.AssessmentReportCause;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AssessmentReportCauseRepository extends JpaRepository<AssessmentReportCause, String> {

}
