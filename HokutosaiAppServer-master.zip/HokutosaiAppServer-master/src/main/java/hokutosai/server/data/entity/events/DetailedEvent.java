package hokutosai.server.data.entity.events;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "events")
public class DetailedEvent extends Event {

}
