package hokutosai.server.data.entity.exhibitions;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "exhibitions")
public class SimpleExhibition extends Exhibition{

}
