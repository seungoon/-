package hokutosai.server.data.entity.shops;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "shops")
public class SimpleShop extends Shop {

}
