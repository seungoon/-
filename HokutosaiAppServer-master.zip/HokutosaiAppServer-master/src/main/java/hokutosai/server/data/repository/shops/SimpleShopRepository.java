package hokutosai.server.data.repository.shops;

import hokutosai.server.data.entity.shops.SimpleShop;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SimpleShopRepository extends JpaRepository<SimpleShop, Integer> {

	public SimpleShop findByShopId(Integer shopId);

}
